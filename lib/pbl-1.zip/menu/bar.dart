import 'package:flutter/material.dart';
import 'package:mobile_studio_gallery/menu/tampilan_utama.dart';
import 'package:mobile_studio_gallery/user/data_pribadi.dart';
import 'package:mobile_studio_gallery/pesanan/tampilan_pesanan.dart';

class BottomNavigation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      backgroundColor: Colors.black,
      currentIndex: 0, // Initial selected tab index
      items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(Icons.home, color: Colors.white),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.history,
              color: Colors
                  .white), // Ganti ikon ke yang sesuai untuk Shopping Cart
          label: 'Histori',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person, color: Colors.white),
          label: 'Profile',
        ),
      ],
      onTap: (int index) {
        if (index == 0) {
          // Navigasi ke halaman Home saat item "Home" dipilih
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => PaketApp()));
        } else if (index == 1) {
          // Navigasi ke halaman Booking saat item "Booking" dipilih
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => PesananPage()));
        } else if (index == 2) {
          // Navigasi ke halaman Profile saat item "Profile" dipilih
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => Tampilan()));
        }
      },
    );
  }
}
