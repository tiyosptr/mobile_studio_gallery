import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_studio_gallery/kesimpulan/tampilan_pembayaran_depan.dart';

class SelectStudio extends StatefulWidget {
  final Map<String, dynamic> paket;
  final int selectedStudioIndex;
  final String selectedDate;
  final String selectedTime;

  // Constructor with named parameters
  
  const SelectStudio(
      {Key? key,
      required this.paket,
      required this.selectedStudioIndex,
      required this.selectedDate,
      required this.selectedTime})
      : super(key: key);
  @override
  _SelectStudioState createState() => _SelectStudioState();
}

class _SelectStudioState extends State<SelectStudio> {
  bool isPaymentUpfront = true;
  bool isMandiriSelected = false;
  bool isBCASelected = false;
  String selectedBank = '';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: Colors.black,
          body: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ),
                Text(
                  'Kesimpulan',
                  style: GoogleFonts.roboto(
                    textStyle: TextStyle(color: Colors.white70, fontSize: 18.0),
                  ),
                ),
                SizedBox(height: 10),
                Center(
                  child: Text(
                    widget.paket['nama_paket'], // Display the selected package
                    style: TextStyle(color: Colors.white, fontSize: 25),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Studio yang dipilih: Studio ${widget.selectedStudioIndex + 1}', // Display the selected studio
                  style: GoogleFonts.roboto(
                    textStyle: TextStyle(color: Colors.white70, fontSize: 18.0),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: 400,
                  height: 200,
                  child: Image.asset(
                    'images/studio${widget.selectedStudioIndex + 1}.png', // Assuming images are named studio1.png, studio2.png, etc.
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Jadwal:',
                  style: TextStyle(color: Colors.white, fontSize: 19),
                  textAlign: TextAlign.left,
                ),
                SizedBox(height: 10),
                Text(
                  'Tanggal: ${widget.selectedDate}\nJam: ${widget.selectedTime}', // Display the selected date and time
                  style: GoogleFonts.roboto(
                    textStyle: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ),
                SizedBox(height: 20),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Pembayaran Didepan\n ${isPaymentUpfront ? 'Rp.${widget.paket['harga'] ~/ 2}' : 'Rp.${widget.paket['harga']}'}',
                            style: TextStyle(
                              color: isPaymentUpfront
                                  ? Colors.white
                                  : Colors.white54,
                              fontSize: 17,
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ),
                        Container(
                          width:
                              18.0, // Sesuaikan lebar Container sesuai kebutuhan
                          height:
                              18.0, // Sesuaikan tinggi Container sesuai kebutuhan
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2.0),
                            border: Border.all(color: Colors.white, width: 2.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white,
                                blurRadius: 2.0,
                                spreadRadius: 1.0,
                                offset: Offset(0, 0),
                              ),
                            ],
                          ),
                          child: Checkbox(
                            value: isPaymentUpfront,
                            onChanged: (value) {
                              setState(() {
                                isPaymentUpfront = value!;
                                // Uncheck both Mandiri and BCA when Pembayaran Didepan is selected
                                if (isPaymentUpfront) {
                                  selectedBank = '';
                                }
                              });
                            },
                            checkColor: Colors.white,
                            activeColor: Colors.blue,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            visualDensity: VisualDensity.compact,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Transfer ke bank',
                      style: GoogleFonts.roboto(
                        textStyle:
                            TextStyle(color: Colors.white, fontSize: 19.0),
                      ),
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Mandiri\n10900********',
                            style: TextStyle(
                              color: selectedBank == 'Mandiri'
                                  ? Colors.white
                                  : Colors.white54,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Container(
                          width:
                              18.0, // Sesuaikan lebar Container sesuai kebutuhan
                          height:
                              18.0, // Sesuaikan tinggi Container sesuai kebutuhan
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2.0),
                            border: Border.all(color: Colors.white, width: 2.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white,
                                blurRadius: 2.0,
                                spreadRadius: 1.0,
                                offset: Offset(0, 0),
                              ),
                            ],
                          ),
                          child: Checkbox(
                            value: selectedBank == 'Mandiri',
                            onChanged: (value) {
                              setState(() {
                                selectedBank = value! ? 'Mandiri' : '';
                                // Uncheck Pembayaran Didepan when Mandiri is selected
                                isPaymentUpfront = false;
                              });
                            },
                            checkColor: Colors.white,
                            activeColor: Colors.blue,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            visualDensity: VisualDensity.compact,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'BCA\n21*********',
                            style: TextStyle(
                              color: selectedBank == 'BCA'
                                  ? Colors.white
                                  : Colors.white54,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Container(
                          width:
                              18.0, // Sesuaikan lebar Container sesuai kebutuhan
                          height:
                              18.0, // Sesuaikan tinggi Container sesuai kebutuhan
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2.0),
                            border: Border.all(color: Colors.white, width: 2.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white,
                                blurRadius: 2.0,
                                spreadRadius: 1.0,
                                offset: Offset(0, 0),
                              ),
                            ],
                          ),
                          child: Checkbox(
                            value: selectedBank == 'BCA',
                            onChanged: (value) {
                              setState(() {
                                selectedBank = value! ? 'BCA' : '';
                                // Uncheck Pembayaran Didepan when BCA is selected
                                isPaymentUpfront = false;
                              });
                            },
                            checkColor: Colors.white,
                            activeColor: Colors.blue,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            visualDensity: VisualDensity.compact,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
          bottomNavigationBar: Builder(
            builder: (context) => Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: ElevatedButton(
                onPressed: () {
                  double harga = widget.paket['harga'].toDouble();

                  // Check if upfront payment is selected, apply 50% discount
                  if (isPaymentUpfront) {
                    harga = harga * 0.5;
                  }

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PembayaranScreen(
                          paket: widget.paket,
                          selectedStudioIndex: widget.selectedStudioIndex,
                          selectedDate: widget.selectedDate,
                          selectedTime: widget.selectedTime,
                          upfrontPaymentSelected: isPaymentUpfront,
                          totalHarga: harga,
                          selectedBank: selectedBank),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  primary: Color(0xFF445256),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Pesan Sekarang',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
